
package kanban;


import static java.lang.Long.SIZE;
import java.util.Scanner;
import javax.swing.JOptionPane;

/**
 * ST10145829
 * @author MICHAEL MEI
 * @version JDK 1.13
 * @since JDK 1.8
 */
public class ST10145829kanBan {

   // Allow the login and Scanner to be shared among all methods
    RegistrationLogin login = new RegistrationLogin();
    taskManager TaskManager = new taskManager();
    TManager tmanager = new TManager();
    Arraytask taskArray = new Arraytask();
    Scanner keyboard = new Scanner(System.in);

    public static void main(String[] args) {
       /* EasyKanban easyKanban = new EasyKanban();
        
        easyKanban.processMenuOption();

        taskManager TaskManager = new taskManager();
        
        TaskArray taskArray = new TaskArray();

        String taskName = TaskManager.getTaskName();*/
        
        Arraytask t = new Arraytask();
        //if(login.loginUser==true)
        t.input();
        
        
                
        //TaskManager.printTaskDetails(TaskManager.getTaskName(),TaskManager., , );
        //TaskManager.getTaskName();
    }
    
        
       
        
    

    /*public void processMenuOption() {
        String selectedOption;
         int i = 2;
        
        while (true) {
            //display welcome screen with options
            JOptionPane.showMessageDialog(null,"Welcome to EasyKanban!!");
            System.out.println("Please enter one of the following 3 OPTIONS: 1) REGISTER(r),  2) LOGIN (l), QUIT (q)");
            System.out.println(">> ");
            //Get selected option
            selectedOption = keyboard.nextLine();

            //process selected option
            switch (selectedOption) 
            {
                case ("r") ://Process registration option requirements ;
                    processRegisterOption();
                case ("l") : {
                    //process login option requirements
                    processLoginOption();
                    
                    
                    
                    {
                        String [] option = {"1","2","3"};

                        String [] option2 = {"RETURN","QUIT"};

                        String [] option3 = {"DOING","TO DO","DONE"};
                        
                        String taskName;
                        String[] getTaskName = taskArray.getTaskName();

                        String taskDescription;
                        

                        String developerDetails;
                        String[] DeveloperDetails = taskArray.DeveloperDetails();

                        int taskDuration;
                        int[] tasksDuration = taskArray.taskDuration();

                        int status;
                        String[] tasksStatus = taskArray.taskStatus();

                        String Identification;

                        String printTaskDetails;
                        

                        int time= 0;
                        int taskNumber = 0;

                        while(true){
                        int x = JOptionPane.showOptionDialog(null,"Welcome to EasyKanban\n" + "Please choose 1 to Add tasks, 2 to Show report or 3 to Quit", "Tasks...",JOptionPane.DEFAULT_OPTION,
                        JOptionPane.QUESTION_MESSAGE, null, option, option[0]);

                        if(x==0){

                        String pseudo = JOptionPane.showInputDialog("How many tasks would you like to enter?");

                        int amount = Integer.parseInt(pseudo);

                        for(i=0;i<amount;i++){

                        taskName = JOptionPane.showInputDialog("Enter Task Name"
                                + "");
                        getTaskName[i]= taskName;

                        taskDescription = JOptionPane.showInputDialog("Enter task description");

                        developerDetails = JOptionPane.showInputDialog("Entetr developer Name and Surname");
                        DeveloperDetails[i] = developerDetails;

                        taskDuration = Integer.parseInt(JOptionPane.showInputDialog("How many hours will it take to complete the task?"));
                        tasksDuration[i] = taskDuration;

                        status = JOptionPane.showOptionDialog(null,"What is the status of the task?", "Tasks...",JOptionPane.DEFAULT_OPTION, JOptionPane.QUESTION_MESSAGE, null, option3, option3[0]);
                       
                        

                        Identification = createTaskID(taskName,developerDetails, taskNumber);

                        taskNumber++;

                        printTaskDetails = printTaskDetails(status,developerDetails,taskNumber,taskName,taskDescription,Identification,time);
                        

                }  
                       
                       int largest = tasksDuration[0];
                       String temp ="";
                        for(int s = 0; s < i; s++){
                            int b = tasksDuration[s];
                                if (b > largest){
                                    temp = getTaskName[s];
                                    largest = b;
                                }
                        }
                       
                            JOptionPane.showMessageDialog(null,"Largest task duration in the array is : " +largest+temp);    
                                                                                
            }

                else if(x==1)

                {
                        
                        for(int z = 0; z<i; z++)
                        {
                            JOptionPane.showMessageDialog(null,getTaskName[z]+"\n"+DeveloperDetails[z]+"\n"+tasksDuration[z]);
                        }

                    x = JOptionPane.showOptionDialog(null, """
                                                           Welcome to EasyKanban
                                                           Please select 1 to Add tasks, 2 to Show report or 3 to Quit""", "Tasks...",JOptionPane.DEFAULT_OPTION,

                    JOptionPane.QUESTION_MESSAGE, null, option, option[0]);
                }

                     if(x==2)
                     {
                    JOptionPane.showMessageDialog(null, """
                                                        Thank You!!
                                                        Have A Good Day!!""");
                     break;
                }

                        }   
               
                   }
               }
                case ("q") -> //the user wants to exit program
                    System.exit(0);
                default -> JOptionPane.showMessageDialog(null,"PLease enter a valid option");

          }

      }
        
        
        
        
    }

    public void processRegisterOption() {
        //Get user information for registration
        System.out.println("Please enter your first name...");
        System.out.println(">> ");
        String userFirstName = keyboard.nextLine();
        System.out.println("Please enter your last name...");
        System.out.println(">> ");
        String userLastName = keyboard.nextLine();
        System.out.println("Please enter a username...");
        System.out.println(">> ");
        String userUsername = keyboard.nextLine();
        System.out.println("Please enter your password");
        System.out.println(">> ");
        String userPassword = keyboard.nextLine();

        //Atempt to register user
        System.out.println(login.registerUser(userFirstName, userLastName, userUsername, userPassword));
        if (login.loginUSer(userUsername, userPassword) == true) {
            System.out.println();
        }
    }

    public void processLoginOption() {
        // Get username and password
        System.out.println("Please enter your username...");
        System.out.print(">>  ");
        String userUsername = keyboard.nextLine();

        System.out.println("please enter your password...");
        System.out.print(">>  ");
        String userPassword = keyboard.nextLine();

        //Attempt to log usrer in
        System.out.println(login.returnLoginStatus(userUsername, login.loginUSer(userUsername, userPassword)));
        System.out.println();
    }
  
        public static String printTaskDetails(int status, String developerDetail, int taskNumber,String taskName,String taskDescription, String Identification, int time){

         String taskStatus = null;

            if(status == 0)

         taskStatus = "To do";

          if(status == 1)

         taskStatus = "Done";

          if(status == 2)
            
         taskStatus = "Doing";

        JOptionPane.showMessageDialog(null,"Task Status" + ": " + taskStatus + "\nDeveloper Details" + ": " + developerDetail +"\nTask Number" + ": " + taskNumber

        + "\nTask Name" + ": " + taskName + "\nTask Description" + ": " + taskDescription + "\nTask ID" + ": " + Identification);

        return taskStatus;

    }   

        public static String createTaskID(String taskName, String developerDetail, int taskNumber){

            String id1 = taskName.substring(0, 2);

            int id2 = taskNumber;

            String id3 = developerDetail.substring(developerDetail.length()-4, developerDetail.length());

            String message = id1 + ":" + id2 + ":" + id3;

            return message.toUpperCase();

            }
        



              public static boolean chechTaskDescription(String taskDescription){

              if(taskDescription.length()<50)

             return true;
            
             else

            return false;
             
            }*/
              
            
              
                     

}


